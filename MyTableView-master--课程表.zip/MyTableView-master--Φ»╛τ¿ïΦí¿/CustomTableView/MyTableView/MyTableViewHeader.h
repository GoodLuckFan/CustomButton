
//
//  MyTableViewHeader.h
//  CustomTableView
//
//  Created by yeqiang on 2018/4/19.
//  Copyright © 2018年 yeqiang. All rights reserved.
//

#ifndef MyTableViewHeader_h
#define MyTableViewHeader_h

#define NOTIF_CELL_SCROLL @"NOTIF_CELL_SCROLL"
#define NOTIF_TABLE_SCROLL @"NOTIF_TABLE_SCROLL"

#define kCELL_HEIGHT 38
#define kCELL_WIDTH 75

#endif /* MyTableViewHeader_h */
