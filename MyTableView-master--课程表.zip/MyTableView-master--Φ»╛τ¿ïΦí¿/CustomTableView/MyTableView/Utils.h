//
//  Utils.h
//  Huafeng
//
//  Created by yeqiang on 2018/3/29.
//  Copyright © 2018年 yeqiang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@interface Utils : NSObject


// 分割线
+ (UIView *)getLineView;



@end
